<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация пользователя</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        
        .container {
            background-color: white;
            border-radius: 10px;
            padding: 30px;
            max-width: 500px;
            width: 100%;
        }
        
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        
        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        
        input:focus, select:focus {
            border-color: #007bff;
            outline: none;
        }
        
        button {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        
        button:hover {
            background-color: #0056b3;
        }
        
        .error {
            color: #dc3545;
            font-size: 14px;
            margin-top: 5px;
        }
        
        .success-message {
            background-color: #ffffff;
            color: black;
            padding: 15px;
            border-radius: 5px;
            border: 1px solid #ffffff;
            margin-bottom: 20px;
        }
        
        .user-data {
            background-color: #f8f9fa;
            border-radius: 5px;
            padding: 20px;
            margin-top: 20px;
        }
        
        .user-data h3 {
            margin-top: 0;
            color: #333;
        }
        
        .user-data p {
            margin: 8px 0;
            color: #555;
        }
        
        .optional {
            font-weight: normal;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Регистрация пользователя</h1>
        
        <?php
        $name = $email = $password = $birthdate = $gender = '';
        $errors = [];
        $success = false;
        $submittedData = [];
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (empty($_POST['name'])) {
                $errors['name'] = 'Введите ваше имя';
            } else {
                $name = htmlspecialchars(trim($_POST['name']));
                if (strlen($name) < 1) {
                    $errors['name'] = 'Имя должно содержать минимум 1 символ';
                }
            }
            
            if (empty($_POST['email'])) {
                $errors['email'] = 'Введите ваш email';
            } else {
                $email = htmlspecialchars(trim($_POST['email']));
                if (strpos($email, '@') === false) {
    $errors['email'] = 'Email должен содержать символ @';
}
            }
            
            if (empty($_POST['password'])) {
                $errors['password'] = 'Введите пароль';
            } else {
                $password = $_POST['password'];
                if (strlen($password) < 6) {
                    $errors['password'] = 'Пароль должен содержать минимум 6 символов';
                }
            }
            
            if (empty($_POST['birthdate'])) {
                $errors['birthdate'] = 'Выберите дату рождения';
            } else {
                $birthdate = $_POST['birthdate'];
                $birthdateObj = DateTime::createFromFormat('Y-m-d', $birthdate);
                $today = new DateTime();
                $age = $birthdateObj->diff($today)->y;
                
                if ($age < 18) {
                    $errors['birthdate'] = 'Вы должны быть старше 18 лет';
                }
            }
            
            if (!empty($_POST['gender'])) {
                $gender = $_POST['gender'];
            }
            
            if (empty($errors)) {
                $success = true;
                
                $genderDisplay = '';
                if ($gender === 'male') {
                    $genderDisplay = 'Мужской';
                } elseif ($gender === 'female') {
                    $genderDisplay = 'Женский';
                } else {
                    $genderDisplay = 'Не указан';
                }
                
                $submittedData = [
                    'name' => $name,
                    'email' => $email,
                    'password' => '********',
                    'birthdate' => date('d.m.Y', strtotime($birthdate)),
                    'gender' => $genderDisplay,
                    'age' => $age,
                    'registration_date' => date('d.m.Y H:i:s')
                ];
            }
        }
        ?>
        
        <?php if ($success): ?>
            <div class="success-message">
                Регистрация успешно завершена! Добро пожаловать, <?php echo $name; ?>!
            </div>
            
            <div class="user-data">
                <h3>Ваши регистрационные данные:</h3>
                <p><strong>Имя:</strong> <?php echo $submittedData['name']; ?></p>
                <p><strong>Email:</strong> <?php echo $submittedData['email']; ?></p>
                <p><strong>Пароль:</strong> <?php echo $submittedData['password']; ?></p>
                <p><strong>Дата рождения:</strong> <?php echo $submittedData['birthdate']; ?></p>
                <p><strong>Пол:</strong> <?php echo $submittedData['gender']; ?></p>
                <p><strong>Возраст:</strong> <?php echo $submittedData['age']; ?> лет</p>
                <p><strong>Дата регистрации:</strong> <?php echo $submittedData['registration_date']; ?></p>
            </div>
            
            <button onclick="window.location.href='?'">Зарегистрировать нового пользователя</button>
            
        <?php else: ?>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="name">Имя:</label>
                    <input type="text" id="name" name="name" 
                           value="<?php echo htmlspecialchars($name); ?>" 
                           placeholder="Введите ваше имя">
                    <?php if (!empty($errors['name'])): ?>
                        <span class="error"><?php echo $errors['name']; ?></span>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" 
                           value="<?php echo htmlspecialchars($email); ?>" 
                           placeholder="example@mail.com">
                    <?php if (!empty($errors['email'])): ?>
                        <span class="error"><?php echo $errors['email']; ?></span>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="password">Пароль:</label>
                    <input type="password" id="password" name="password" 
                           placeholder="Минимум 6 символов">
                    <?php if (!empty($errors['password'])): ?>
                        <span class="error"><?php echo $errors['password']; ?></span>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="birthdate">Дата рождения:</label>
                    <input type="date" id="birthdate" name="birthdate" 
                           value="<?php echo htmlspecialchars($birthdate); ?>"
                           max="<?php echo date('Y-m-d'); ?>">
                    <?php if (!empty($errors['birthdate'])): ?>
                        <span class="error"><?php echo $errors['birthdate']; ?></span>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="gender">Пол:</label>
                    <select id="gender" name="gender">
                        <option value="">Не указывать</option>
                        <option value="male" <?php echo ($gender === 'male') ? 'selected' : ''; ?>>Мужской</option>
                        <option value="female" <?php echo ($gender === 'female') ? 'selected' : ''; ?>>Женский</option>
                    </select>
                </div>
                
                <button type="submit">Зарегистрироваться</button>
            </form>
        <?php endif; ?>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('birthdate').max = today;
        });
    </script>
</body>
</html>