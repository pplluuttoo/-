<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Таблица умножения (0-10)</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        table {
            border-collapse: collapse;
            margin: 20px auto;
            background-color: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
            min-width: 40px;
        }
        th {
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
	}
	td.header {
    		background-color: #4CAF50;  
    		color: white;
    		font-weight: bold;
		}

        tr:nth-child(even) td:not(.header) {
            background-color: #f9f9f9;
        }

    </style>
</head>
<body>
    <h1>Таблица умножения от 0 до 10</h1>
    
    <?php
    $start = 0;
    $end = 10;
    
    echo "<table>";
    

    echo "<tr>";
    echo "<th>×</th>"; 
    for ($i = $start; $i <= $end; $i++){
        echo "<th>$i</th>";
    }
    echo "</tr>";
    
    // Тело таблицы
    for ($i = $start; $i <= $end; $i++) {
        echo "<tr>";
        echo "<td class='header'>$i</td>"; // Заголовок строки
        
        for ($j = $start; $j <= $end; $j++) {
            $result = $i * $j;
            $class = "";
            
            // Добавляем класс для диагонали
            if ($i == $j) {
                $class = "diagonal";
            }
            
            echo "<td class='$class'>$result</td>";
        }
        echo "</tr>";
    }
    
    echo "</table>";
    ?>
    
    
</body>
</html>