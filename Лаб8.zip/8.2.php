<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Календарь</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: #ffffff;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 15px;
            padding: 30px;
            max-width: 500px;
            width: 100%;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        .controls {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        select, button {
            padding: 10px 15px;
            border: 2px solid #34495e;
            border-radius: 8px;
            font-size: 16px;
            background: white;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        select:hover, button:hover {
            background: #34495e;
            color: white;
        }

        .calendar {
            background: white;
            border-radius: 10px;
            overflow: hidden;
        }

        .calendar-header {
            background: #34495e;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 1.5em;
            font-weight: bold;
        }

        .week-days {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            background: #2c3e50;
            color: white;
        }

        .week-day {
            padding: 10px;
            text-align: center;
            font-weight: bold;
        }

        .calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 1px;
            background: #bdc3c7;
        }

        .calendar-cell {
            background: white;
            padding: 15px 5px;
            text-align: center;
            min-height: 60px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            position: relative;
            transition: all 0.3s ease;
        }

        .empty {
            background: #f8f9fa;
        }

        .weekend {
            background: #e74c3c !important;
            color: white;
        }

        .holiday {
            background: #27ae60 !important;
            color: white;
            position: relative;
        }

        .holiday::after {
            position: absolute;
            top: 2px;
            right: 2px;
            font-size: 12px;
        }

        .current-day {
            border: 4px solid #34495e;
            font-weight: bold;
        }

        .day-number {
            font-size: 1.2em;
            font-weight: bold;
        }

        .day-info {
            font-size: 0.7em;
            margin-top: 2px;
            opacity: 0.8;
        }

        @media (max-width: 480px) {
            .calendar-cell {
                padding: 10px 2px;
                min-height: 50px;
            }
            
            .day-number {
                font-size: 1em;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Календарь</h1>
        
        <form method="GET" action="" id="calendarForm">
            <div class="controls">
                <select name="month" id="monthSelect">
                    <?php
                    $months = [
                        'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
                        'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
                    ];
                    
                    $currentMonth = isset($_GET['month']) ? (int)$_GET['month'] : date('n') - 1;
                    
                    for ($i = 0; $i < 12; $i++) {
                        $selected = ($i == $currentMonth) ? 'selected' : '';
                        echo "<option value='$i' $selected>{$months[$i]}</option>";
                    }
                    ?>
                </select>
                
                <select name="year" id="yearSelect">
                    <?php
                    $currentYear = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
                    $startYear = date('Y') - 5;
                    $endYear = date('Y') + 5;
                    
                    for ($year = $startYear; $year <= $endYear; $year++) {
                        $selected = ($year == $currentYear) ? 'selected' : '';
                        echo "<option value='$year' $selected>$year</option>";
                    }
                    ?>
                </select>
                
                <button type="submit">Обновить</button>
                <button type="button" onclick="showCurrentMonth()">Текущий месяц</button>
            </div>
        </form>

        <div class="calendar">
            <?php

            function displayCalendar($month = null, $year = null) {
                // Если параметры не заданы, используем текущую дату
                if ($month === null) $month = date('n') - 1; // 0-11
                if ($year === null) $year = date('Y');
                
                // Массив праздничных дней
                $holidays = [
                    '01-01' => 'Новый год',
                    '01-02' => 'Новый год',
                    '01-03' => 'Новый год',
                    '01-04' => 'Новый год',
                    '01-05' => 'Новый год',
                    '01-06' => 'Новый год',
                    '01-07' => 'Рождество',
                    '01-08' => 'Новый год',
                    '02-23' => 'День защитника Отечества',
                    '03-08' => 'Международный женский день',
                    '05-01' => 'Праздник весны и труда',
                    '05-09' => 'День Победы',
                    '06-12' => 'День России',
                    '11-04' => 'День народного единства'
                ];
                
                $months = [
                    'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
                    'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
                ];
                
                $currentDay = date('j');
                $currentMonthNum = date('n') - 1;
                $currentYear = date('Y');

                $firstDay = mktime(0, 0, 0, $month + 1, 1, $year);
                $lastDay = mktime(0, 0, 0, $month + 2, 0, $year);
                
                $daysInMonth = date('t', $firstDay);
                $firstDayOfWeek = date('N', $firstDay); 

                echo "<div class='calendar-header'>{$months[$month]} $year</div>";

                echo "<div class='week-days'>";
                $weekDays = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
                foreach ($weekDays as $day) {
                    $style = ($day == 'Сб' || $day == 'Вс') ? 'style="background: #e74c3c;"' : '';
                    echo "<div class='week-day' $style>$day</div>";
                }
                echo "</div>";

                echo "<div class='calendar-grid'>";

                for ($i = 1; $i < $firstDayOfWeek; $i++) {
                    echo "<div class='calendar-cell empty'></div>";
                }

                for ($day = 1; $day <= $daysInMonth; $day++) {

                    $date = mktime(0, 0, 0, $month + 1, $day, $year);
                    $dayOfWeek = date('w', $date); 
                    

                    $classes = ['calendar-cell'];
                    
                    if ($dayOfWeek == 0 || $dayOfWeek == 6) {
                        $classes[] = 'weekend';
                    }
                    
                    $dateKey = sprintf('%02d-%02d', $month + 1, $day);
                    $isHoliday = isset($holidays[$dateKey]);
                    if ($isHoliday) {
                        $classes[] = 'holiday';
                    }
                    
                    $isToday = ($day == $currentDay && $month == $currentMonthNum && $year == $currentYear);
                    if ($isToday) {
                        $classes[] = 'current-day';
                    }
                    
                    echo "<div class='" . implode(' ', $classes) . "'>";
                    echo "<div class='day-number'>$day</div>";
                    
                    if ($isHoliday) {
                        echo "<div class='day-info'>{$holidays[$dateKey]}</div>";
                    }
                    
                    echo "</div>";
                }
                
                echo "</div>";
            }
            
            $month = isset($_GET['month']) ? (int)$_GET['month'] : null;
            $year = isset($_GET['year']) ? (int)$_GET['year'] : null;

            displayCalendar($month, $year);
            ?>
        </div>
    </div>

    <script>
        function showCurrentMonth() {
            const now = new Date();
            const currentMonth = now.getMonth();
            const currentYear = now.getFullYear();
            
            document.getElementById('monthSelect').value = currentMonth;
            document.getElementById('yearSelect').value = currentYear;

            document.getElementById('calendarForm').submit();
        }
        
        document.getElementById('monthSelect').addEventListener('change', function() {
            document.getElementById('calendarForm').submit();
        });
        
        document.getElementById('yearSelect').addEventListener('change', function() {
            document.getElementById('calendarForm').submit();
        });
    </script>
</body>
</html>