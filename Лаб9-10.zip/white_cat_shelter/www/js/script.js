// Функция для показа модального окна знакомства
function showAdoptionModal(animalId) {
    <?php if (isLoggedIn()): ?>
        // Пользователь авторизован - показываем форму заявки
        const modalContent = document.getElementById('modalContent');
        modalContent.innerHTML = `
            <form id="adoptionForm" onsubmit="submitAdoptionForm(event, ${animalId})">
                <div class="form-group">
                    <label for="message">Расскажите о себе и условиях для животного:</label>
                    <textarea id="message" name="message" rows="4" required 
                              placeholder="Напишите немного о себе, вашем жилье и опыте с животными"></textarea>
                </div>
                <button type="submit" class="btn">Отправить заявку</button>
            </form>
            <div id="formMessage" class="message" style="display:none;"></div>
        `;
    <?php else: ?>
        // Пользователь не авторизован - предлагаем войти
        const modalContent = document.getElementById('modalContent');
        modalContent.innerHTML = `
            <p>Для подачи заявки на знакомство необходимо авторизоваться.</p>
            <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                <a href="login.php" class="btn">Войти</a>
                <a href="register.php" class="btn btn-accent">Зарегистрироваться</a>
            </div>
        `;
    <?php endif; ?>
    
    document.getElementById('adoptionModal').style.display = 'block';
}

// Закрытие модального окна
function closeAdoptionModal() {
    document.getElementById('adoptionModal').style.display = 'none';
}

// Закрытие модального окна при клике вне его
window.onclick = function(event) {
    const modal = document.getElementById('adoptionModal');
    if (event.target === modal) {
        closeAdoptionModal();
    }
}

// Отправка формы заявки
function submitAdoptionForm(event, animalId) {
    event.preventDefault();
    
    const formData = new FormData();
    formData.append('animal_id', animalId);
    formData.append('message', document.getElementById('message').value);
    
    fetch('process_request.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        const messageDiv = document.getElementById('formMessage');
        if (data.success) {
            messageDiv.className = 'message success';
            messageDiv.textContent = data.message;
            messageDiv.style.display = 'block';
            
            // Очистка формы
            document.getElementById('adoptionForm').reset();
            
            // Закрытие модального окна через 2 секунды
            setTimeout(() => {
                closeAdoptionModal();
            }, 2000);
        } else {
            messageDiv.className = 'message error';
            messageDiv.textContent = data.message;
            messageDiv.style.display = 'block';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        const messageDiv = document.getElementById('formMessage');
        messageDiv.className = 'message error';
        messageDiv.textContent = 'Произошла ошибка при отправке заявки';
        messageDiv.style.display = 'block';
    });
}

// Загрузка данных животного при нажатии на кнопку
document.addEventListener('DOMContentLoaded', function() {
    // Добавляем обработчики событий для кнопок "Познакомиться"
    const adoptButtons = document.querySelectorAll('.btn-adopt');
    adoptButtons.forEach(button => {
        button.addEventListener('click', function() {
            const animalId = this.closest('.animal-card').dataset.animalId;
            showAdoptionModal(animalId);
        });
    });
});