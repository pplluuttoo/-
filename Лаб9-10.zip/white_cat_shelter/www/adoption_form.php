<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Проверка, передан ли ID животного
$animal_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$animal_id) {
    header('Location: index.php');
    exit;
}

// Получение информации о животном
$stmt = $pdo->prepare("
    SELECT a.*, ac.curator_name, ac.curator_phone, ac.work_hours 
    FROM animals a 
    LEFT JOIN animal_contacts ac ON a.id = ac.animal_id 
    WHERE a.id = ?
");
$stmt->execute([$animal_id]);
$animal = $stmt->fetch();

if (!$animal) {
    header('Location: index.php');
    exit;
}

// Проверка авторизации при отправке формы
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_application'])) {
    if (!isLoggedIn()) {
        header('Location: login.php?redirect=' . urlencode('adoption_form.php?id=' . $animal_id));
        exit;
    }
    
    $phone = trim($_POST['phone'] ?? '');
    $convenient_time = trim($_POST['convenient_time'] ?? '');
    $experience = trim($_POST['experience'] ?? '');
    $housing = trim($_POST['housing'] ?? '');
    $other_pets = trim($_POST['other_pets'] ?? '');
    $additional_info = trim($_POST['additional_info'] ?? '');
    
    // Валидация
    if (empty($phone)) {
        $error = 'Пожалуйста, укажите ваш телефон';
    } else {
        // Сохранение заявки в БД
        $stmt = $pdo->prepare("
            INSERT INTO adoption_requests 
            (user_id, animal_id, message, phone, convenient_time, experience, housing, other_pets, additional_info) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        // Формируем сообщение из всех данных анкеты
        $message = "Телефон: $phone\n";
        $message .= "Удобное время: $convenient_time\n";
        $message .= "Опыт с животными: $experience\n";
        $message .= "Условия проживания: $housing\n";
        $message .= "Другие животные: $other_pets\n";
        $message .= "Дополнительная информация: $additional_info";
        
        $success_query = $stmt->execute([
            $_SESSION['user_id'],
            $animal_id,
            $message,
            $phone,
            $convenient_time,
            $experience,
            $housing,
            $other_pets,
            $additional_info
        ]);
        
        if ($success_query) {
            $success = 'Ваша заявка успешно отправлена! Мы свяжемся с вами в ближайшее время.';
        } else {
            $error = 'Ошибка при отправке заявки. Пожалуйста, попробуйте позже.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Анкета для знакомства - <?php echo htmlspecialchars($animal['name']); ?></title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .animal-detail {
            display: flex;
            gap: 2rem;
            margin-bottom: 2rem;
            padding: 1.5rem;
            background-color: var(--accent-color);
            border-radius: 8px;
        }
        
        .animal-image-large {
            width: 300px;
            height: 300px;
            object-fit: cover;
            border-radius: 8px;
        }
        
        .animal-info-detail {
            flex: 1;
        }
        
        .contact-info {
            background-color: #f0e68c;
            padding: 1rem;
            border-radius: 6px;
            margin: 1rem 0;
            border-left: 4px solid var(--primary-color);
        }
        
        .form-section {
            background-color: var(--secondary-color);
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        @media (max-width: 768px) {
            .animal-detail {
                flex-direction: column;
            }
            
            .animal-image-large {
                width: 100%;
                height: 250px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main>
        <div class="container">
            <h1>Знакомство с <?php echo htmlspecialchars($animal['name']); ?></h1>
            
            <div class="animal-detail">
                <img src="<?php echo htmlspecialchars($animal['image_path']); ?>" 
                     alt="<?php echo htmlspecialchars($animal['name']); ?>" 
                     class="animal-image-large">
                
                <div class="animal-info-detail">
                    <h2><?php echo htmlspecialchars($animal['name']); ?></h2>
                    <p><strong>Порода:</strong> <?php echo htmlspecialchars($animal['breed']); ?></p>
                    <p><strong>Возраст:</strong> <?php echo htmlspecialchars($animal['age']); ?></p>
                    <p><strong>Описание:</strong> <?php echo htmlspecialchars($animal['description']); ?></p>
                    
                    <div class="contact-info">
                        <h3> Контакты для животного:</h3>
                        <p><strong>Куратор:</strong> Инна Петровна</p>
                        <p><strong>Телефон куратора:</strong> +7 (983) 508-55-90</p>
                        <p><strong>Часы работы:</strong> Пн-Пт с 10:00 до 18:00</p>
                        <p><em>После подачи заявки куратор свяжется с вами для уточнения деталей</em></p>
                    </div>
                </div>
            </div>
            
            <div class="form-section">
                <h2>Заполните анкету для знакомства</h2>
                
                <?php if (!isLoggedIn()): ?>
                    <div class="message" style="background-color: #fff3cd; color: #856404; border: 1px solid #ffeaa7;">
                        <p>Для подачи заявки необходимо <a href="login.php?redirect=<?php echo urlencode('adoption_form.php?id=' . $animal_id); ?>">войти</a> или <a href="register.php">зарегистрироваться</a>.</p>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="message error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="message success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                
                <form method="POST" action="" <?php echo !isLoggedIn() ? 'onsubmit="alert(\'Пожалуйста, войдите или зарегистрируйтесь!\'); return false;"' : ''; ?>>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="phone">Ваш телефон *:</label>
                            <input type="tel" id="phone" name="phone" 
                                   placeholder="+7 (999) 123-45-67" 
                                   value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>"
                                   required <?php echo !isLoggedIn() ? 'disabled' : ''; ?>>
                        </div>
                        
                        <div class="form-group">
                            <label for="convenient_time">Удобное время для звонка:</label>
                            <select id="convenient_time" name="convenient_time" <?php echo !isLoggedIn() ? 'disabled' : ''; ?>>
                                <option value="">Выберите время</option>
                                <option value="утро (9:00-12:00)">Утро (9:00-12:00)</option>
                                <option value="день (12:00-15:00)">День (12:00-15:00)</option>
                                <option value="вечер (15:00-18:00)">Вечер (15:00-18:00)</option>
                                <option value="любое время">Любое время</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="experience">Опыт содержания животных:</label>
                        <textarea id="experience" name="experience" rows="3" 
                                  placeholder="Был ли у вас опыт содержания кошек? Если да, расскажите немного"
                                  <?php echo !isLoggedIn() ? 'disabled' : ''; ?>><?php echo isset($_POST['experience']) ? htmlspecialchars($_POST['experience']) : ''; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="housing">Условия проживания:</label>
                        <textarea id="housing" name="housing" rows="3" 
                                  placeholder="Квартира или дом? Есть ли доступ на улицу? Какие условия для животного?"
                                  <?php echo !isLoggedIn() ? 'disabled' : ''; ?>><?php echo isset($_POST['housing']) ? htmlspecialchars($_POST['housing']) : ''; ?></textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="other_pets">Есть ли другие животные?</label>
                            <select id="other_pets" name="other_pets" <?php echo !isLoggedIn() ? 'disabled' : ''; ?>>
                                <option value="">Выберите вариант</option>
                                <option value="нет">Нет других животных</option>
                                <option value="кошки">Есть кошки</option>
                                <option value="собаки">Есть собаки</option>
                                <option value="другие">Другие животные</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="additional_info">Дополнительная информация:</label>
                            <textarea id="additional_info" name="additional_info" rows="3" 
                                      placeholder="Любая дополнительная информация, которую считаете важной"
                                      <?php echo !isLoggedIn() ? 'disabled' : ''; ?>><?php echo isset($_POST['additional_info']) ? htmlspecialchars($_POST['additional_info']) : ''; ?></textarea>
                        </div>
                    </div>
                    
                    <div class="form-group" style="margin-top: 1.5rem;">
                        <input type="checkbox" id="agree_terms" name="agree_terms" required <?php echo !isLoggedIn() ? 'disabled' : ''; ?>>
                        <label for="agree_terms" style="display: inline;">
                            Я согласен(а) на обработку персональных данных и подтверждаю, что ознакомлен(а) с условиями содержания животного
                        </label>
                    </div>
                    
                    <?php if (isLoggedIn()): ?>
                        <button type="submit" name="submit_application" class="btn" style="margin-top: 1rem;">
                            Отправить заявку
                        </button>
                    <?php else: ?>
                        <a href="login.php?redirect=<?php echo urlencode('adoption_form.php?id=' . $animal_id); ?>" class="btn">
                            Войти для подачи заявки
                        </a>
                    <?php endif; ?>
                </form>
            </div>
            
            <div style="margin-top: 2rem; text-align: center;">
                <a href="index.php" class="btn btn-accent">← Вернуться к списку животных</a>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    
    <script>
    // Автозаполнение времени, если пользователь авторизован
    document.addEventListener('DOMContentLoaded', function() {
        <?php if (isLoggedIn()): ?>
            // Можно добавить автозаполнение данных пользователя
            const userPhone = '<?php echo isset($_SESSION["phone"]) ? $_SESSION["phone"] : ""; ?>';
            if (userPhone && !document.getElementById('phone').value) {
                document.getElementById('phone').value = userPhone;
            }
        <?php endif; ?>
    });
    </script>
</body>
</html>