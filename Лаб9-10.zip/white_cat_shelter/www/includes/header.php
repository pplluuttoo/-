<?php
require_once 'includes/auth.php';
?>
<header>
    <div class="container">
        <a href="index.php" class="logo">
            <i class="fas fa-cat"></i> Белый кот
        </a>
        
        <nav>
            <ul>
                <li><a href="index.php"><i class="fas fa-home"></i> Главная</a></li>
                <li><a href="index.php#animals"><i class="fas fa-paw"></i> Наши животные</a></li>
                
                <?php if (isLoggedIn()): ?>
                    <li><a href="profile.php"><i class="fas fa-user"></i> Мой профиль</a></li>
                    
                    <?php if (isAdmin()): ?>
                        <li><a href="admin.php"><i class="fas fa-cog"></i> Админ-панель</a></li>
                    <?php endif; ?>
                    
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Выйти (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a></li>
                <?php else: ?>
                    <li><a href="login.php"><i class="fas fa-sign-in-alt"></i> Войти</a></li>
                    <li><a href="register.php"><i class="fas fa-user-plus"></i> Регистрация</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>