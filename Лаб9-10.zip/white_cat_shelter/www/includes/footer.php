<footer>
    <div class="container">
        <p>Приют для животных «Белый кот» &copy; <?php echo date('Y'); ?></p>
        <p>Все права защищены. Контакты: info@whitecat.ru, +7 (983) 508-55-90</p> 
        <p>Мы заботимся о каждом пушистом друге!</p>
    </div>
</footer>