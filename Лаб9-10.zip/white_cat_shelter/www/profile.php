<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Если пользователь не авторизован, перенаправляем на страницу входа
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user = getCurrentUser();
$error = '';
$success = '';

// Обработка обновления профиля
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $email = trim($_POST['email'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Некорректный email адрес';
    } else {
        $stmt = $pdo->prepare("UPDATE users SET email = ?, full_name = ?, phone = ?, address = ? WHERE id = ?");
        $success = $stmt->execute([$email, $full_name, $phone, $address, $_SESSION['user_id']]);
        
        if ($success) {
            $_SESSION['email'] = $email;
            $_SESSION['full_name'] = $full_name;
            $success_message = 'Профиль успешно обновлен';
            $user = getCurrentUser(); // Обновляем данные пользователя
        } else {
            $error = 'Ошибка при обновлении профиля';
        }
    }
}

// Получение заявок пользователя
$stmt = $pdo->prepare("
    SELECT ar.*, a.name as animal_name, a.image_path 
    FROM adoption_requests ar 
    JOIN animals a ON ar.animal_id = a.id 
    WHERE ar.user_id = ? 
    ORDER BY ar.request_date DESC
");
$stmt->execute([$_SESSION['user_id']]);
$requests = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мой профиль - Приют «Белый кот»</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main>
        <div class="container">
            <h1>Мой профиль</h1>
            
            <?php if ($error): ?>
                <div class="message error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if (isset($success_message)): ?>
                <div class="message success"><?php echo htmlspecialchars($success_message); ?></div>
            <?php endif; ?>
            
            <div class="profile-container">
                <div class="profile-info">
                    <h2>Личные данные</h2>
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="username">Имя пользователя:</label>
                            <input type="text" id="username" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="full_name">ФИО:</label>
                            <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Телефон:</label>
                            <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="address">Адрес:</label>
                            <textarea id="address" name="address" rows="3"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                        </div>
                        
                        <button type="submit" name="update_profile" class="btn">Сохранить изменения</button>
                    </form>
                </div>
                
                <div class="profile-requests">
                    <h2>Мои заявки на знакомство</h2>
                    
                    <?php if (empty($requests)): ?>
                        <p>У вас пока нет заявок на знакомство с животными.</p>
                    <?php else: ?>
                        <div class="requests-list">
                            <?php foreach ($requests as $request): ?>
                                <div class="request-item">
                                    <div style="display: flex; align-items: center; gap: 1rem;">
                                        <img src="<?php echo htmlspecialchars($request['image_path']); ?>" 
                                             alt="<?php echo htmlspecialchars($request['animal_name']); ?>"
                                             style="width: 80px; height: 80px; object-fit: cover; border-radius: 4px;">
                                        <div>
                                            <h3><?php echo htmlspecialchars($request['animal_name']); ?></h3>
                                            <p>Дата заявки: <?php echo date('d.m.Y H:i', strtotime($request['request_date'])); ?></p>
                                            <p>Статус: 
                                                <?php 
                                                switch ($request['status']) {
                                                    case 'pending': echo '<span style="color: orange;">На рассмотрении</span>'; break;
                                                    case 'approved': echo '<span style="color: green;">Одобрена</span>'; break;
                                                    case 'rejected': echo '<span style="color: red;">Отклонена</span>'; break;
                                                    default: echo $request['status'];
                                                }
                                                ?>
                                            </p>
                                        </div>
                                    </div>
                                    <?php if (!empty($request['message'])): ?>
                                        <?php if (!empty($request['message'])): ?>
    <div class="request-details" style="margin-top: 1rem; padding: 1rem; background-color: #f9f9f9; border-radius: 4px;">
        <h4>Детали заявки:</h4>
        <?php 
        // Разбиваем сообщение на строки
        $details = explode("\n", $request['message']);
        foreach ($details as $detail):
            if (!empty(trim($detail))):
        ?>
            <p><?php echo htmlspecialchars($detail); ?></p>
        <?php 
            endif;
        endforeach; 
        
        // Дополнительные поля
        if (!empty($request['phone'])) {
            echo "<p><strong>Телефон:</strong> " . htmlspecialchars($request['phone']) . "</p>";
        }
        if (!empty($request['convenient_time'])) {
            echo "<p><strong>Удобное время:</strong> " . htmlspecialchars($request['convenient_time']) . "</p>";
        }
        ?>
    </div>
<?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
    
    <?php include 'includes/footer.php'; ?>
    
    <style>
    .profile-container {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 2rem;
        margin-top: 2rem;
    }
    
    .profile-info, .profile-requests {
        background-color: var(--accent-color);
        padding: 1.5rem;
        border-radius: 8px;
    }
    
    .request-item {
        background-color: var(--secondary-color);
        padding: 1rem;
        border-radius: 4px;
        margin-bottom: 1rem;
        border: 1px solid #ddd;
    }
    
    @media (max-width: 768px) {
        .profile-container {
            grid-template-columns: 1fr;
        }
    }
    </style>
</body>
</html>