<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Приют для животных «Белый кот»</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main>
        <section class="hero">
            <div class="container">
                <h1>Приют для животных «Белый кот»</h1>
                <p>Дарим любовь и заботу каждому пушистому другу</p>
            </div>
        </section>
        
        <section class="animals" id="animals">
            <div class="container">
                <h2>Наши питомцы ищут дом</h2>
                <p>Все кошки здоровы, привиты и стерилизованы. Познакомьтесь с ними!</p>
                
                <div class="animals-grid">
                    <?php
                    // Получение списка животных из базы данных
                    $stmt = $pdo->query("SELECT * FROM animals WHERE status = 'available'");
                    $animals = $stmt->fetchAll();
                    
                    foreach ($animals as $animal):
                    ?>
                    <div class="animal-card" data-animal-id="<?php echo $animal['id']; ?>">
                        <img src="<?php echo htmlspecialchars($animal['image_path']); ?>" 
                             alt="<?php echo htmlspecialchars($animal['name']); ?>" 
                             class="animal-img">
                        <div class="animal-info">
                            <h3><?php echo htmlspecialchars($animal['name']); ?></h3>
                            <div class="breed">Порода: <?php echo htmlspecialchars($animal['breed']); ?></div>
                            <div class="age">Возраст: <?php echo htmlspecialchars($animal['age']); ?></div>
                            <p class="description"><?php echo htmlspecialchars($animal['description']); ?></p>
                            <a href="adoption_form.php?id=<?php echo $animal['id']; ?>" class="btn btn-adopt">
                                Познакомиться
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    </main>
    
    <!-- Модальное окно для заявки на знакомство -->
    <div id="adoptionModal" class="modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeAdoptionModal()">&times;</span>
            <h2>Заявка на знакомство</h2>
            <div id="modalContent">
                <!-- Контент будет загружен через JavaScript -->
            </div>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    
    <script src="js/script.js"></script>
</body>
</html>