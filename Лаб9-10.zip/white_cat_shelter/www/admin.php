<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Проверка прав администратора
if (!isAdmin()) {
    header('Location: index.php');
    exit;
}

// Обработка действий администратора
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_animal'])) {
        // Добавление нового животного
        $name = trim($_POST['name'] ?? '');
        $breed = trim($_POST['breed'] ?? '');
        $age = trim($_POST['age'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $image_path = trim($_POST['image_path'] ?? '');
        
        if (!empty($name)) {
            $stmt = $pdo->prepare("INSERT INTO animals (name, breed, age, description, image_path) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $breed, $age, $description, $image_path]);
        }
    } elseif (isset($_POST['update_user'])) {
        // Обновление пользователя
        $user_id = $_POST['user_id'] ?? 0;
        $role = $_POST['role'] ?? 'user';
        
        if ($user_id > 0) {
            $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE id = ?");
            $stmt->execute([$role, $user_id]);
        }
    } elseif (isset($_POST['update_request'])) {
        // Обновление статуса заявки
        $request_id = $_POST['request_id'] ?? 0;
        $status = $_POST['status'] ?? 'pending';
        
        if ($request_id > 0) {
            $stmt = $pdo->prepare("UPDATE adoption_requests SET status = ? WHERE id = ?");
            $stmt->execute([$status, $request_id]);
        }
    }
}

// Получение всех пользователей
$users_stmt = $pdo->query("SELECT * FROM users ORDER BY created_at DESC");
$users = $users_stmt->fetchAll();

// Получение всех заявок
$requests_stmt = $pdo->query("
    SELECT ar.*, u.username, a.name as animal_name 
    FROM adoption_requests ar 
    JOIN users u ON ar.user_id = u.id 
    JOIN animals a ON ar.animal_id = a.id 
    ORDER BY ar.request_date DESC
");
$all_requests = $requests_stmt->fetchAll();

// Получение всех животных
$animals_stmt = $pdo->query("SELECT * FROM animals ORDER BY name");
$all_animals = $animals_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора - Приют «Белый кот»</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main>
        <div class="container">
            <h1>Панель администратора</h1>
            
            <div class="admin-sections">
                <!-- Добавление нового животного -->
                <section class="admin-section">
                    <h2>Добавить новое животное</h2>
                    <form method="POST" action="" class="admin-form">
                        <div class="form-group">
                            <label for="name">Имя:</label>
                            <input type="text" id="name" name="name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="breed">Порода:</label>
                            <input type="text" id="breed" name="breed">
                        </div>
                        
                        <div class="form-group">
                            <label for="age">Возраст:</label>
                            <input type="text" id="age" name="age">
                        </div>
                        
                        <div class="form-group">
                            <label for="description">Описание:</label>
                            <textarea id="description" name="description" rows="3"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="image_path">Путь к изображению:</label>
                            <input type="text" id="image_path" name="image_path" placeholder="images/animals/cat.jpg">
                        </div>
                        
                        <button type="submit" name="add_animal" class="btn">Добавить животное</button>
                    </form>
                </section>
                
                <!-- Управление пользователями -->
                <section class="admin-section">
                    <h2>Пользователи</h2>
                    <div class="admin-table-container">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Имя пользователя</th>
                                    <th>Email</th>
                                    <th>Роль</th>
                                    <th>Дата регистрации</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?php echo $user['id']; ?></td>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td>
                                        <form method="POST" action="" style="display: inline;">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <select name="role" onchange="this.form.submit()">
                                                <option value="user" <?php echo $user['role'] === 'user' ? 'selected' : ''; ?>>Пользователь</option>
                                                <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Администратор</option>
                                            </select>
                                            <input type="hidden" name="update_user">
                                        </form>
                                    </td>
                                    <td><?php echo date('d.m.Y', strtotime($user['created_at'])); ?></td>
                                    <td>
                                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                        <form method="POST" action="" style="display: inline;">
                                            <!-- Здесь можно добавить удаление пользователей -->
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </section>
                
                <!-- Управление заявками -->
                <section class="admin-section">
                    <h2>Заявки на знакомство</h2>
                    <div class="admin-table-container">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Пользователь</th>
                                    <th>Животное</th>
                                    <th>Дата заявки</th>
                                    <th>Статус</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($all_requests as $request): ?>
                                <tr>
                                    <td><?php echo $request['id']; ?></td>
                                    <td><?php echo htmlspecialchars($request['username']); ?></td>
                                    <td><?php echo htmlspecialchars($request['animal_name']); ?></td>
                                    <td><?php echo date('d.m.Y H:i', strtotime($request['request_date'])); ?></td>
                                    <td>
                                        <form method="POST" action="" style="display: inline;">
                                            <input type="hidden" name="request_id" value="<?php echo $request['id']; ?>">
                                            <select name="status" onchange="this.form.submit()">
                                                <option value="pending" <?php echo $request['status'] === 'pending' ? 'selected' : ''; ?>>На рассмотрении</option>
                                                <option value="approved" <?php echo $request['status'] === 'approved' ? 'selected' : ''; ?>>Одобрена</option>
                                                <option value="rejected" <?php echo $request['status'] === 'rejected' ? 'selected' : ''; ?>>Отклонена</option>
                                            </select>
                                            <input type="hidden" name="update_request">
                                        </form>
                                    </td>
                                    <td>
                                        <button onclick="showRequestDetails(<?php echo $request['id']; ?>, '<?php echo htmlspecialchars($request['message']); ?>')" class="btn btn-small">
                                            Подробнее
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>
    </main>
    
    <!-- Модальное окно для деталей заявки -->
    <div id="requestModal" class="modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeRequestModal()">&times;</span>
            <h2>Детали заявки</h2>
            <div id="requestDetails">
                <!-- Контент будет загружен через JavaScript -->
            </div>
        </div>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    
    <script>
    function showRequestDetails(requestId, message) {
        const detailsDiv = document.getElementById('requestDetails');
        detailsDiv.innerHTML = `
            <p><strong>ID заявки:</strong> ${requestId}</p>
            <p><strong>Сообщение от пользователя:</strong></p>
            <div style="background-color: #f5f5f5; padding: 1rem; border-radius: 4px; margin: 1rem 0;">
                ${message || 'Сообщение не указано'}
            </div>
        `;
        document.getElementById('requestModal').style.display = 'block';
    }
    
    function closeRequestModal() {
        document.getElementById('requestModal').style.display = 'none';
    }
    
    // Закрытие модального окна при клике вне его
    window.onclick = function(event) {
        const modal = document.getElementById('requestModal');
        if (event.target === modal) {
            closeRequestModal();
        }
    }
function showRequestDetails(requestId, message, phone, convenientTime) {
    const detailsDiv = document.getElementById('requestDetails');
    detailsDiv.innerHTML = `
        <p><strong>ID заявки:</strong> ${requestId}</p>
        <p><strong>Телефон:</strong> ${phone || 'Не указан'}</p>
        <p><strong>Удобное время:</strong> ${convenientTime || 'Не указано'}</p>
        <p><strong>Сообщение от пользователя:</strong></p>
        <div style="background-color: #f5f5f5; padding: 1rem; border-radius: 4px; margin: 1rem 0;">
            ${message || 'Сообщение не указано'}
        </div>
    `;
    document.getElementById('requestModal').style.display = 'block';
}
    </script>
    
    <style>
    .admin-sections {
        display: grid;
        grid-template-columns: 1fr;
        gap: 2rem;
        margin-top: 2rem;
    }
    
    .admin-section {
        background-color: var(--accent-color);
        padding: 1.5rem;
        border-radius: 8px;
    }
    
    .admin-form {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1rem;
    }
    
    .admin-form .form-group {
        margin-bottom: 0;
    }
    
    .admin-form button {
        grid-column: span 2;
    }
    
    .admin-table-container {
        overflow-x: auto;
    }
    
    .admin-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 1rem;
    }
    
    .admin-table th,
    .admin-table td {
        padding: 0.75rem;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    
    .admin-table th {
        background-color: var(--primary-color);
        color: var(--secondary-color);
    }
    
    .admin-table tr:hover {
        background-color: rgba(0,0,0,0.05);
    }
    
    .btn-small {
        padding: 0.3rem 0.6rem;
        font-size: 0.9rem;
    }
    
    select {
        padding: 0.3rem;
        border-radius: 4px;
        border: 1px solid #ddd;
    }
    
    @media (max-width: 768px) {
        .admin-form {
            grid-template-columns: 1fr;
        }
        
        .admin-form button {
            grid-column: span 1;
        }
    }
    </style>
</body>
</html>