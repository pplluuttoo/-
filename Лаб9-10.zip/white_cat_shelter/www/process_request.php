<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Проверка авторизации
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Требуется авторизация']);
    exit;
}

// Проверка метода запроса
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
    exit;
}

// Получение данных из формы
$animal_id = filter_input(INPUT_POST, 'animal_id', FILTER_VALIDATE_INT);
$message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);

// Валидация данных
if (!$animal_id || !$message) {
    echo json_encode(['success' => false, 'message' => 'Пожалуйста, заполните все поля']);
    exit;
}

// Проверка существования животного
$stmt = $pdo->prepare("SELECT * FROM animals WHERE id = ? AND status = 'available'");
$stmt->execute([$animal_id]);
$animal = $stmt->fetch();

if (!$animal) {
    echo json_encode(['success' => false, 'message' => 'Животное недоступно для заявки']);
    exit;
}

// Проверка существования заявки от этого пользователя на это животное
$stmt = $pdo->prepare("SELECT id FROM adoption_requests WHERE user_id = ? AND animal_id = ?");
$stmt->execute([$_SESSION['user_id'], $animal_id]);
$existing_request = $stmt->fetch();

if ($existing_request) {
    echo json_encode(['success' => false, 'message' => 'Вы уже отправили заявку на это животное']);
    exit;
}

// Создание заявки
$stmt = $pdo->prepare("INSERT INTO adoption_requests (user_id, animal_id, message) VALUES (?, ?, ?)");
$success = $stmt->execute([$_SESSION['user_id'], $animal_id, $message]);

if ($success) {
    echo json_encode(['success' => true, 'message' => 'Заявка успешно отправлена! Мы свяжемся с вами в ближайшее время.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Ошибка при отправке заявки']);
}
?>